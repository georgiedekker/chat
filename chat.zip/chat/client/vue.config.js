module.exports = {
  // transpileDependencies: [
  //   'vuetify'
  // ]
}
