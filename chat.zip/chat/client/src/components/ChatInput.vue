<template>
        <form>
          <label for="chatMessage">Chat Message</label>
          <input id="userName" type="text" autocomplete="off" v-model="this.user.name"/>
          <input id="chatMessage" type="text" autocomplete="off" v-model="this.chatMessage"/>
          <button v-on:click.stop.prevent="submit(chatMessage, this.user)">Send</button>
        </form>

  <p>Message is: {{ messageChat.message }}</p>
  <p>User name is: {{ user.name }}</p>
 
</template>

<script>
// import { Socket } from 'socket.io-client';
import SocketioService from '../../services/socketio.service';
console.log('user from SocketioService: '+JSON.stringify(SocketioService.user))
export default {
  name: 'ChatInput',
  
  data()  {
    return { 
      chatMessage:'',
      room: Math.floor(Math.random()*1000),
      userName:'',
      user: SocketioService.user,
      messageChat:'',
      messages:[]
    }
  //   // return this.chatMessage
  },
  methods:{
    // created(){
    // const user = SocketioService.socketCreated()
    // return user},
    // unmounted(){
    // SocketioService.disconnect()
    // },
    async submit (chatMessage,user){ 
      // console.log('received message: '+chatMessage+' user: '+user.name+user.timeStamp)
      this.user = SocketioService.user
      this.user.name = user.name
      const messageChat = await SocketioService.sendMessage(chatMessage, this.user)
      console.log('user that was sent: '+JSON.stringify(this.user))
      // this.user = messageChat.user
      // this.messages.push(messageChat.message)
      console.log('messageChat: '+JSON.stringify(messageChat))
      console.log('user from SocketioService: '+JSON.stringify(SocketioService.user))
      // this.messages.push(messageChat.message)
      // this.user = messageChat.user.timeStamp
      // return this.messages, this.user

      // console.log('messages: '+this.messageChat)
      // if(messageChat?.message){
        // chatMessage = messageChat
      // }
      // return  chatMessage
      // }
      this.chatMessage = '';
      document.getElementById('chatMessage').focus()
      }
    // receiveMessage:((chatMessage)=>{socketioService.receiveMessage(chatMessage);console.log('message: '+chatMessage)},'')
  }
}
</script>
