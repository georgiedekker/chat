<template>

 <ChatInput/>

</template>

<script>
import ChatInput from './components/ChatInput.vue'
// import AppBar from './components/AppBar.vue'
// import Chats from './components/Chats.vue'
import SocketioService from '../services/socketio.service';

export default {
  name: 'App',
  user:{},
  components: {
    ChatInput,
    // AppBar,
    // Chats
  },

  data: () => ({
    user:{}
  }),
  created(){
const user = SocketioService.socketCreated()
return user
  },
  unmounted(){
SocketioService.disconnect()
  }
}
</script>
